********************************************************************************

Hi Familia, thanks for purchasing SmtpEx V4 with me @killo_trojanz
I thank you guys because I will give this money for my mother's medicine costs.

********************************************************************************

  _________        __        ___________               ____   _________  
 /   _____/ ______/  |_______\_   _____/__  ___        \   \ /   /  |  | 
 \_____  \ /     \   __\____ \|    __)_\  \/  /  ______ \   Y   /   |  |_
 /        \  Y Y  \  | |  |_> >        \>    <  /_____/  \     /    ^   /
/_______  /__|_|  /__| |   __/_______  /__/\_ \           \___/\____   | 
        \/      \/     |__|          \/      \/                     |__| 

                          [SmtpEx-V4] 
this tool is the tool with the best laravel exploit now. class price of $ 50 this tool
can compete with other tools that cost 120 $-200 $, Why? because this tool is the only tool for the
laravel smtp cracker that uses a connector on the list so you can be sure that the list you enter will be properly sorted
so that you get the best results too. and also SmtpEx is an SMTP and Aws Cracker tool with all types so this tool is really fresh 
for all of you who want to crack on smtp and aws because this tool has adopted RCE V9, the latest rce created by a Laravel programmer directly 
to test exploit resistance on laravel CMS. unwittingly the bug spread but not everyone can use the bug because the bug contains a combined exploit of 
all exploits published in 2022, that's why the bug is called RCE V9. So why can this tool compete with other very expensive tools? 
because on average they only use RCE V3 and V4 which were published in 2017 so we can be sure that RCE in that year cannot be adapted to the current Laravel CMS,
which is increasingly secure.

with this tool you can do the cracking stages on many laravel IPs at once you can get your best results with this tool. this tool is based on bash and python,
to adapt this tool with RCE V9 I use the bash program to more easily get requests and use python to get maximum speed and also this tool has been refined to 
become an exe with the help of Visual Studio with the help of Python Gui and also C# in order to be able to print Exe 
with speed that adapts to python and also a strong connection to the BASH program system. this tool is well encrypted using PYARMOR and also BINARI
so you can be sure this tool will not be cracked. this tool is a lifetime so no need to be afraid of this tool at any time will die, and also if you buy 
this tool you don't need to buy another smtp cracker tool, as I said above this tool has adapted to the RCE V9 program so this RCE will not be outdated because 
this RCE is the latest RCE

*********************************************************************************

                      [ How To Run ]

 # Open And Extrack ZIP/RAR 
 # Perform the installation steps on the installer
 # Go to the SmtpEx V4 folder location
 # If you have found the tool there then you just need to get a list of your IPs.
 # If you have got the list then go back into the folder
 # Save your list with .txt extension
 # Then Open SmtpEx V4.exe with double click / Run as Administrator

 # ( List IPs/Domain --> ) input your list like :
                        - List IPs/Domain --> ip.txt [Click Enter]

 # ( Thread (Default : 200) --> ) input your Thread (Speed) Like :
                        - Thread (Default : 200) --> 200 [Click Enter]

 # Then your result will appear in the Result folder. If your results don't appear then be patient, it means your list is not good.
 # Make sure your internet connection is stable so no errors occur
 

 [i] If the device closes immediately and your connection is not stable, it means your device is closed because your connection is bad
 [/] If your device exits and your connection is good then that means your tool has finished exploiting and cracking your list.

*********************************************************************************

                  [ Very Important ]

This tool uses a premium license so this tool can only be installed on 2 devices and no more. Because if you exceed the usage limit,
Apikey in this case will automatically revoke your device's license and disable it so that the tool continues to run but cannot crack. 
If this happens it means you have violated the rules and you must buy it again.


*********************************************************************************







